//
//  books.swift
//  iOS
//
//  Created by epita on 29/03/2018.
//  Copyright © 2018 epita. All rights reserved.
//

import Foundation

class Books { // : superclass (not the case here)

    var author : String?
    var title : String?
    var year : String?
    var description : String?
    var imageName : String?
    
    
    init(author:String, title:String, year:String, description:String) {
        
        self.author = author
        self.title = title
        self.year = year
        self.description = description
        self.imageName = "bookCover.jpg"
        
        
    }
    
}

