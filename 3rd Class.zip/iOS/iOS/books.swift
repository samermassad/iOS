//
//  books.swift
//  iOS
//
//  Created by epita on 29/03/2018.
//  Copyright © 2018 epita. All rights reserved.
//

import Foundation

class Books { // : superclass (not the case here)

    var author : String?
    var title : String?
    var publisher : String?
    
    init(author:String, title:String, publisher:String) {
        
        self.author = author
        self.publisher = publisher
        self.title = title
        
    }
    
}

